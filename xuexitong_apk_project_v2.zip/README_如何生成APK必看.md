# 学习通刷课助手 Pro — 独立安卓 APK 专用工程包（方案二专享版）

本压缩包是已配置好**根目录结构**的完整 Android 原生工程，内置：
1. **顶部原生导航栏**：自带「课程主页」、「呼出面板」、「刷新」三个快捷按钮与防息屏常亮指示。
2. **原生免手势自动播放 + 拦截官方 App 唤醒 + 桌面端 UA 伪装**。
3. **原生 Java 跨域桥接（`AndroidBridge`）**：在 APK 内使用 DeepSeek AI 自动答题 100% 免跨域、免本地黑窗口。
4. **手机触屏拖拽适配版 V3 Pro 面板**（位于 `app/src/main/assets/xuexitong_inject.js`）。

---

## 3 分钟免费云端生成 `.apk` 安装包（电脑无需安装任何编程软件）

### 第一步：解压并上传到 GitHub
1. 将本压缩包解压到一个空文件夹。
2. 登录 [GitHub](https://github.com/)，点击右上角 **`+` -> `New repository`**，输入任意名称（如 `xxt-apk`），勾选 **`Add a README file`**，点击 **`Create repository`**。
3. 进入仓库后，点击 **`Add file` -> `Upload files`**：
   - 将解压出来的 **`app`** 文件夹、**`build.gradle`**、**`settings.gradle`**、**`gradle.properties`** 直接拖入网页上传，点击底部的 **`Commit changes`**。

### 第二步：激活云端自动打包（最关键一步）
> 注意：用网页拖拽上传时，有时隐藏文件夹 `.github` 会被浏览器忽略。如果上传后顶部 `Actions` 没有自动运行，请按以下操作：
1. 点击仓库顶部的 **`Actions`** 标签页 -> 点击 **`set up a workflow yourself`**（或者回到代码页点击 `Add file` -> `Create new file`，文件名填 `.github/workflows/build_apk.yml`）。
2. 打开解压文件夹里的 **`复制我到GitHub_Actions打包配置.yml`**，将里面的内容全部复制粘贴进去，点击右上角 **`Commit changes`**。

### 第三步：下载生成的 `.apk` 到手机安装
1. 点击仓库顶部的 **`Actions`** 标签页，你会看到 **`Build Android APK`** 正在自动编译（黄色圆圈旋转，约耗时 1.5 ~ 2 分钟）。
2. 变成绿色对勾 `✅` 后，点击进入该任务，滑到页面最底部的 **`Artifacts`** 区域。
3. 点击下载 **`Xuexitong-OneClick-V3-Pro-APK`**，解压即可拿到 **`app-debug.apk` / `app-release.apk`**，发到安卓手机直接安装即可！
