package com.oneclick.xuexitong;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private String injectScriptContent = "";

    // 伪装桌面端 Edge 浏览器 UA，确保超星学习通加载完整网页端课程目录与视频播放器
    private static final String DESKTOP_UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0";

    private static final String HOME_URL = "https://i.chaoxing.com/";

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 强制屏幕常亮，防止手机挂机刷课时息屏断网
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        injectScriptContent = loadAssetText("xuexitong_inject.js");

        // 构建顶部原生快捷导航栏 + 底部 WebView 布局
        LinearLayout rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout topBar = buildNativeTopBar();
        rootLayout.addView(topBar);

        webView = new WebView(this);
        LinearLayout.LayoutParams webParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.0f);
        webView.setLayoutParams(webParams);
        rootLayout.addView(webView);

        setContentView(rootLayout);

        setupWebView();
        webView.loadUrl(HOME_URL);
    }

    private LinearLayout buildNativeTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(Color.parseColor("#111827"));
        bar.setGravity(Gravity.CENTER_VERTICAL);
        int padH = dp(10);
        int padV = dp(6);
        bar.setPadding(padH, padV, padH, padV);

        TextView titleView = new TextView(this);
        titleView.setText("⚡ 学习通刷课Pro (防息屏常亮中)");
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        titleView.setLayoutParams(titleLp);
        bar.addView(titleView);

        Button homeBtn = makeTopButton("课程主页");
        homeBtn.setOnClickListener(v -> {
            if (webView != null) webView.loadUrl(HOME_URL);
        });
        bar.addView(homeBtn);

        Button injectBtn = makeTopButton("呼出面板");
        injectBtn.setOnClickListener(v -> {
            if (webView != null) {
                webView.evaluateJavascript("window.__XUEXITONG_V3_PRO_LOADED__ = false;", null);
                webView.evaluateJavascript(injectScriptContent, null);
                Toast.makeText(this, "已重新注入一键刷课悬浮面板", Toast.LENGTH_SHORT).show();
            }
        });
        bar.addView(injectBtn);

        Button refreshBtn = makeTopButton("刷新");
        refreshBtn.setOnClickListener(v -> {
            if (webView != null) webView.reload();
        });
        bar.addView(refreshBtn);

        return bar;
    }

    private Button makeTopButton(String text) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btn.setTextColor(Color.WHITE);
        btn.setBackgroundColor(Color.parseColor("#2563EB"));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(32));
        lp.leftMargin = dp(6);
        btn.setLayoutParams(lp);
        btn.setPadding(dp(8), 0, dp(8), 0);
        return btn;
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false); // 关键：允许无手势自动播放视频
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        settings.setUserAgentString(DESKTOP_UA);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);

        // 注入原生 JavaScript 桥接对象，供 DeepSeek AI 答题免跨域调用
        webView.addJavascriptInterface(new NativeJsBridge(), "AndroidBridge");

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    return false;
                }
                // 拦截 chaoxing:// 等拉起手机端官方学习通 App 的自定义协议
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (url != null && url.contains("chaoxing.com")) {
                    view.evaluateJavascript(injectScriptContent, null);
                }
            }
        });
    }

    public class NativeJsBridge {
        @JavascriptInterface
        public String requestDeepSeek(String apiKey, String payloadJson) {
            HttpURLConnection conn = null;
            try {
                URL url = new URL("https://api.deepseek.com/chat/completions");
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(30000);
                conn.setReadTimeout(60000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                conn.setRequestProperty("Authorization", "Bearer " + (apiKey != null ? apiKey.trim() : ""));

                byte[] bodyBytes = payloadJson.getBytes(StandardCharsets.UTF_8);
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(bodyBytes);
                }

                int code = conn.getResponseCode();
                InputStream is = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
                StringBuilder sb = new StringBuilder();
                if (is != null) {
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = br.readLine()) != null) {
                            sb.append(line);
                        }
                    }
                }

                JSONObject result = new JSONObject();
                if (code >= 200 && code < 300) {
                    JSONObject respObj = new JSONObject(sb.toString());
                    JSONArray choices = respObj.optJSONArray("choices");
                    if (choices != null && choices.length() > 0) {
                        String content = choices.getJSONObject(0).getJSONObject("message").getString("content");
                        result.put("ok", true);
                        result.put("content", content);
                        return result.toString();
                    }
                }
                result.put("ok", false);
                result.put("error", "HTTP " + code + ": " + sb.toString());
                return result.toString();
            } catch (Exception e) {
                try {
                    JSONObject err = new JSONObject();
                    err.put("ok", false);
                    err.put("error", e.getMessage());
                    return err.toString();
                } catch (Exception ignored) {
                    return "{"ok":false,"error":"请求异常"}";
                }
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
    }

    private String loadAssetText(String fileName) {
        try (InputStream is = getAssets().open(fileName);
             ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int len;
            while ((len = is.read(buffer)) != -1) {
                baos.write(buffer, 0, len);
            }
            return baos.toString(StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            return "";
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView != null && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
