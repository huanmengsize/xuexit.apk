// ==UserScript==
// @name         学习通自动刷课助手 V3 Pro（可视化一键操作版）
// @namespace    https://github.com/chaolucky18/xuexitongScript
// @version      3.5.0
// @description  基于 chaolucky18/xuexitongScript V3 稳定版深度重制：新增可视化悬浮控制面板、一键启动/暂停、倍速与无视频跳过开关、实时状态日志，以及免本地服务的 DeepSeek 测验辅助功能
// @author       chaolucky18 & OneClick Repackage
// @match        *://mooc1.chaoxing.com/mycourse/studentstudy*
// @match        *://*.chaoxing.com/mycourse/studentstudy*
// @match        *://*.chaoxing.com/mooc2-ans/mycourse/studentstudy*
// @run-at       document-idle
// @grant        GM_xmlhttpRequest
// @grant        GM_setValue
// @grant        GM_getValue
// @connect      api.deepseek.com
// ==/UserScript==

(function () {
    'use strict';

    // 防止重复注入
    if (window.__XUEXITONG_V3_PRO_LOADED__) {
        console.log('[学习通助手 Pro] 脚本已在运行中，无需重复执行。');
        return;
    }
    window.__XUEXITONG_V3_PRO_LOADED__ = true;

    const STORAGE_KEY = 'xxt_v3_pro_configs_v1';

    const defaultConfigs = {
        running: true,               // 是否处于自动刷课状态
        playbackRate: 1.0,           // 默认 1.0x 最稳妥，面板可切 1.25 / 1.5 / 2.0
        muted: true,                 // 默认静音以绕过浏览器自动播放限制
        autoAdvanceNoVideo: true,    // 遇到无视频课件是否自动跳下一节（面板可一键开关）
        noVideoWaitSeconds: 6,       // 无视频页面等待秒数后跳转
        quizMode: 'skip',            // 'skip' (跳过测验) | 'pause' (遇到测验暂停提醒) | 'ai' (DeepSeek 辅助答题)
        deepseekApiKey: '',          // DeepSeek API Key（可选）
        deepseekModel: 'deepseek-chat',
        autoSubmitQuiz: false,       // AI 选完答案后是否自动提交（默认仅勾选，安全第一）
        retryInterval: 2000,
        maxRetries: 10,
        videoCheckInterval: 1500,
        maxQuizSkipAttempts: 3,
        minimized: false
    };

    function loadConfigs() {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            if (raw) {
                return Object.assign({}, defaultConfigs, JSON.parse(raw));
            }
        } catch (e) {
            console.warn('[学习通助手 Pro] 读取配置失败，使用默认配置:', e);
        }
        return Object.assign({}, defaultConfigs);
    }

    function saveConfigs(cfg) {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(cfg));
        } catch (e) {
            console.warn('[学习通助手 Pro] 保存配置失败:', e);
        }
    }

    const app = {
        configs: loadConfigs(),
        state: {
            currentVideo: null,
            retryCount: 0,
            quizSkipCount: 0,
            noVideoTimer: null,
            noVideoWaitCount: 0,
            checkTimer: null,
            statusText: '初始化中...',
            progressText: '等待识别任务',
            lastUnitTitle: '',
            aiBusy: false
        },

        // 日志输出与面板同步
        log(msg, type = 'info') {
            const timeStr = new Date().toLocaleTimeString('zh-CN', { hour12: false });
            const prefix = `[${timeStr}]`;
            console.log(`[学习通助手 Pro] ${msg}`);
            const logBox = document.getElementById('xxt-pro-log-list');
            if (logBox) {
                const item = document.createElement('div');
                item.className = `xxt-log-item xxt-log-${type}`;
                item.textContent = `${prefix} ${msg}`;
                logBox.insertBefore(item, logBox.firstChild);
                while (logBox.children.length > 40) {
                    logBox.removeChild(logBox.lastChild);
                }
            }
        },

        setStatus(statusText, progressText) {
            if (statusText) this.state.statusText = statusText;
            if (progressText !== undefined) this.state.progressText = progressText;
            const statusEl = document.getElementById('xxt-pro-status-badge');
            const progEl = document.getElementById('xxt-pro-progress-text');
            const toggleBtn = document.getElementById('xxt-pro-toggle-btn');

            if (statusEl) {
                statusEl.textContent = this.configs.running ? this.state.statusText : '已暂停';
                statusEl.className = 'xxt-badge ' + (this.configs.running ? 'xxt-badge-active' : 'xxt-badge-paused');
            }
            if (progEl && progressText !== undefined) {
                progEl.textContent = this.state.progressText;
            }
            if (toggleBtn) {
                toggleBtn.textContent = this.configs.running ? '⏸ 暂停自动刷课' : '▶ 一键开始刷课';
                toggleBtn.className = 'xxt-btn xxt-btn-primary ' + (this.configs.running ? 'xxt-btn-running' : 'xxt-btn-stopped');
            }
        },

        // 递归获取页面及所有同源 iframe 的 document
        getAllDocuments(rootDoc = document) {
            const docs = [rootDoc];
            const iframes = rootDoc.querySelectorAll('iframe');
            for (const frame of iframes) {
                try {
                    const childDoc = frame.contentDocument || (frame.contentWindow && frame.contentWindow.document);
                    if (childDoc) {
                        docs.push(...this.getAllDocuments(childDoc));
                    }
                } catch (e) {
                    // 跨域 iframe 忽略
                }
            }
            return docs;
        },

        // 1. 检查是否停留在“学习目标”页签，若是则自动切换到顶部的“2视频 / 视频”页签
        trySwitchToVideoTab() {
            const docs = this.getAllDocuments();
            for (const doc of docs) {
                const tabs = Array.from(doc.querySelectorAll('.tabtags span, .prev_ul li, .ans-job-icon, a, span[title]'));
                for (const tab of tabs) {
                    const text = (tab.textContent || tab.getAttribute('title') || '').trim();
                    if (/^(2\s*)?视频$/.test(text) || text.includes('2视频')) {
                        const isCurrent = tab.classList.contains('currents') || tab.classList.contains('active') ||
                            (tab.parentElement && (tab.parentElement.classList.contains('currents') || tab.parentElement.classList.contains('active')));
                        if (!isCurrent) {
                            this.log('检测到顶部“视频”标签未激活，正在自动切入视频页...', 'action');
                            tab.click();
                            return true;
                        }
                    }
                }
            }
            return false;
        },

        // 2. 寻找真实视频元素 <video>
        findVideoElement() {
            const docs = this.getAllDocuments();
            for (const doc of docs) {
                const video = doc.querySelector('video#video_html5_api, video');
                if (video) return video;
            }
            return null;
        },

        // 3. 寻找章节测验特征
        findQuizContext() {
            const docs = this.getAllDocuments();
            for (const doc of docs) {
                const quizForm = doc.querySelector('.TiMu, .ZyBottom, #form1, .questionLi, .singleQuesId');
                if (quizForm) return { doc, container: quizForm };
            }
            return null;
        },

        // 4. 控制并守护视频播放
        handleVideo(video) {
            this.state.noVideoWaitCount = 0;

            // 绑定一次性的 ended 监听
            if (this.state.currentVideo !== video) {
                this.state.currentVideo = video;
                this.state.retryCount = 0;
                this.state.quizSkipCount = 0;
                this.log('已锁定当前章节视频播放器，准备自动播放...', 'success');

                video.addEventListener('ended', () => {
                    this.log('当前视频播放完毕！即将自动切换下一小节...', 'success');
                    this.setStatus('视频已完成', '100% - 正在跳转下一节');
                    setTimeout(() => {
                        if (this.configs.running) this.nextUnit();
                    }, 1500);
                });
            }

            // 同步静音与倍速配置
            if (this.configs.muted && !video.muted) {
                video.muted = true;
            } else if (!this.configs.muted && video.muted) {
                video.muted = false;
            }

            const targetRate = Number(this.configs.playbackRate) || 1.0;
            if (Math.abs(video.playbackRate - targetRate) > 0.05) {
                try {
                    video.playbackRate = targetRate;
                } catch (e) {}
            }

            // 更新进度展示
            if (video.duration && !isNaN(video.duration)) {
                const pct = Math.min(100, Math.round((video.currentTime / video.duration) * 100));
                const curMin = Math.floor(video.currentTime / 60);
                const curSec = Math.floor(video.currentTime % 60).toString().padStart(2, '0');
                const totMin = Math.floor(video.duration / 60);
                const totSec = Math.floor(video.duration % 60).toString().padStart(2, '0');
                this.setStatus('正在播放视频', `进度: ${pct}% (${curMin}:${curSec} / ${totMin}:${totSec}) · ${targetRate}x`);
            } else {
                this.setStatus('正在加载视频', '等待视频元数据...');
            }

            // 若视频已播放结束
            if (video.ended) {
                this.nextUnit();
                return;
            }

            // 若视频处于暂停状态则自动恢复播放
            if (video.paused) {
                if (this.state.retryCount >= this.configs.maxRetries) {
                    this.setStatus('播放受阻', '已达最大重试次数，请手动点击视频播放');
                    return;
                }
                this.state.retryCount++;
                video.play().then(() => {
                    this.state.retryCount = 0;
                    this.log(`视频播放成功（倍速 ${targetRate}x，${video.muted ? '静音' : '有声'}）`, 'success');
                }).catch((err) => {
                    // 处理 AbortError 或浏览器非静音拦截
                    if (!video.muted) {
                        this.log('普通播放被浏览器拦截，自动切换为静音播放...', 'warn');
                        video.muted = true;
                        this.configs.muted = true;
                        saveConfigs(this.configs);
                        this.syncPanelInputs();
                        video.play().catch(() => {});
                    } else {
                        this.log(`恢复播放重试中 (${this.state.retryCount}/${this.configs.maxRetries}): ${err.name}`, 'warn');
                    }
                });
            }
        },

        // 5. 处理章节测验页
        async handleQuizPage(quizCtx) {
            this.setStatus('检测到章节测验', `当前策略: ${this.configs.quizMode === 'skip' ? '自动跳过' : (this.configs.quizMode === 'ai' ? 'AI 辅助作答' : '暂停等待手动完成')}`);

            if (this.configs.quizMode === 'pause') {
                this.log('当前为章节测验页，已按设置暂停，请手动完成或点击“跳到下一节”。', 'warn');
                this.configs.running = false;
                saveConfigs(this.configs);
                this.setStatus('测验暂停中', '请完成测验后重新开启');
                return;
            }

            if (this.configs.quizMode === 'ai') {
                if (!this.configs.deepseekApiKey) {
                    this.log('未配置 DeepSeek API Key，自动回退为跳过测验模式。', 'warn');
                } else {
                    await this.runDeepSeekQuizHelper(quizCtx.doc);
                    return;
                }
            }

            // 默认 V3 行为：受限尝试点击 #prevNextFocusNext 跳过测验（最多 3 次防止死循环）
            if (this.state.quizSkipCount < this.configs.maxQuizSkipAttempts) {
                this.state.quizSkipCount++;
                const nextBtn = document.querySelector('#prevNextFocusNext') || this.findNextButtonInDocs();
                if (nextBtn) {
                    this.log(`章节测验页：正在尝试跳过测验 (${this.state.quizSkipCount}/${this.configs.maxQuizSkipAttempts})...`, 'action');
                    nextBtn.click();
                    return;
                }
            }

            this.log('跳过按钮已达尝试上限，直接从课程目录树切换下一小节...', 'action');
            this.state.quizSkipCount = 0;
            this.nextUnit();
        },

        // 6. DeepSeek AI 辅助答题（无需本地黑窗口，直接通过油猴/扩展跨域请求）
        async runDeepSeekQuizHelper(quizDoc) {
            if (this.state.aiBusy) return;
            this.state.aiBusy = true;

            try {
                const questionBlocks = Array.from(quizDoc.querySelectorAll('.TiMu, .questionLi, .singleQuesId'));
                if (questionBlocks.length === 0) {
                    this.log('未能在测验页提取到题目结构，将尝试跳到下一节。', 'warn');
                    this.nextUnit();
                    return;
                }

                const extracted = questionBlocks.map((block, idx) => {
                    const titleEl = block.querySelector('.Zy_TItle, .mark_name, h3, .question-title') || block;
                    const optionEls = Array.from(block.querySelectorAll('li, .answerBg, .stem_answer > div'));
                    const options = optionEls.map(el => el.innerText.replace(/\s+/g, ' ').trim()).filter(Boolean);
                    return {
                        index: idx + 1,
                        title: titleEl.innerText.replace(/\s+/g, ' ').trim().slice(0, 300),
                        options,
                        element: block,
                        optionEls
                    };
                });

                this.log(`已识别到 ${extracted.length} 道测验题，正在请求 DeepSeek AI 分析答案...`, 'action');
                this.setStatus('AI 正在解题', `共 ${extracted.length} 题，请稍候...`);

                const promptText = extracted.map(q =>
                    `第${q.index}题：${q.title}\n选项：\n${q.options.map((o, i) => `  [${i}] ${o}`).join('\n')}`
                ).join('\n\n');

                const payload = {
                    model: this.configs.deepseekModel || 'deepseek-chat',
                    messages: [
                        {
                            role: 'system',
                            content: '你是严谨的课程测验解题助手。请针对每道题返回最匹配的选项索引数组（0开始）或判断结果。仅输出合法JSON格式：{"answers":[{"index":1,"choiceIndices":[0],"reason":"简短理由"}]}'
                        },
                        {
                            role: 'user',
                            content: promptText
                        }
                    ],
                    temperature: 0.1,
                    response_format: { type: 'json_object' }
                };

                const responseText = await this.requestDeepSeek(payload);
                const parsed = JSON.parse(responseText);
                const answerList = parsed.answers || [];

                let matchedCount = 0;
                for (const ans of answerList) {
                    const targetQ = extracted.find(q => q.index === ans.index);
                    if (targetQ && Array.isArray(ans.choiceIndices)) {
                        for (const cIdx of ans.choiceIndices) {
                            const optEl = targetQ.optionEls[cIdx];
                            if (optEl) {
                                const clickable = optEl.querySelector('input, a, label, span') || optEl;
                                clickable.click();
                                matchedCount++;
                            }
                        }
                        this.log(`第 ${ans.index} 题已自动勾选 (选项 ${ans.choiceIndices.map(i => String.fromCharCode(65 + i)).join(',')})`, 'success');
                    }
                }

                this.setStatus('AI 勾选完成', `已完成 ${matchedCount} 项勾选`);
                if (!this.configs.autoSubmitQuiz) {
                    this.log('AI 已完成勾选！为保证安全，已暂停自动跳转，请核对后点击提交或点击“下一节”。', 'success');
                    this.configs.running = false;
                    saveConfigs(this.configs);
                    this.setStatus('待核对提交', 'AI 已勾选答案，请核对');
                } else {
                    this.log('AI 勾选完成，3 秒后尝试跳转下一节...', 'success');
                    setTimeout(() => this.nextUnit(), 3000);
                }
            } catch (err) {
                this.log(`DeepSeek AI 答题出错: ${err.message || err}，请检查 API Key 是否有效`, 'error');
                this.configs.running = false;
                saveConfigs(this.configs);
                this.setStatus('AI 调用异常', '请检查设置中的 API Key');
            } finally {
                this.state.aiBusy = false;
            }
        },

        requestDeepSeek(payload) {
            return new Promise((resolve, reject) => {
                const apiUrl = 'https://api.deepseek.com/chat/completions';
                const headers = {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.configs.deepseekApiKey.trim()}`
                };

                                // 优先使用 Android APK 原生 Bridge 绕过所有跨域限制
                if (typeof window.AndroidBridge !== 'undefined' && typeof window.AndroidBridge.requestDeepSeek === 'function') {
                    try {
                        const rawRes = window.AndroidBridge.requestDeepSeek(
                            this.configs.deepseekApiKey.trim(),
                            JSON.stringify(payload)
                        );
                        const parsedRes = JSON.parse(rawRes);
                        if (parsedRes && parsedRes.ok) {
                            resolve(parsedRes.content);
                        } else {
                            reject(new Error((parsedRes && parsedRes.error) || 'APK 原生请求失败'));
                        }
                    } catch (e) {
                        reject(new Error('调用 Android 原生接口异常: ' + e.message));
                    }
                    return;
                }
                // 其次使用油猴 GM_xmlhttpRequest 绕过页面 CORS 限制
                if (typeof GM_xmlhttpRequest === 'function') {
                    GM_xmlhttpRequest({
                        method: 'POST',
                        url: apiUrl,
                        headers,
                        data: JSON.stringify(payload),
                        timeout: 60000,
                        onload: (res) => {
                            if (res.status >= 200 && res.status < 300) {
                                try {
                                    const data = JSON.parse(res.responseText);
                                    resolve(data.choices[0].message.content);
                                } catch (e) {
                                    reject(new Error('解析 DeepSeek 响应失败'));
                                }
                            } else {
                                reject(new Error(`HTTP ${res.status}: ${res.statusText}`));
                            }
                        },
                        onerror: () => reject(new Error('网络请求被拦截或连接失败')),
                        ontimeout: () => reject(new Error('请求 DeepSeek 超时'))
                    });
                } else if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
                    // 浏览器扩展后台代理请求
                    chrome.runtime.sendMessage({
                        type: 'DEEPSEEK_REQUEST',
                        apiKey: this.configs.deepseekApiKey.trim(),
                        payload
                    }, (res) => {
                        if (res && res.ok) resolve(res.content);
                        else reject(new Error((res && res.error) || '扩展后台请求失败'));
                    });
                } else {
                    // 普通 fetch 回退
                    fetch(apiUrl, {
                        method: 'POST',
                        headers,
                        body: JSON.stringify(payload)
                    }).then(r => r.json()).then(data => {
                        if (data.choices && data.choices[0]) resolve(data.choices[0].message.content);
                        else reject(new Error(data.error?.message || '未知 API 错误'));
                    }).catch(reject);
                }
            });
        },

        findNextButtonInDocs() {
            const docs = this.getAllDocuments();
            for (const doc of docs) {
                const btn = doc.querySelector('#prevNextFocusNext, .jb_btn_92.fr.fs14.next, .nextChapter');
                if (btn && btn.offsetParent !== null) return btn;
            }
            return null;
        },

        // 7. 切换到下一小节（兼容新旧版学习通目录树结构）
        nextUnit() {
            this.state.currentVideo = null;
            this.state.retryCount = 0;
            this.state.noVideoWaitCount = 0;

            // 方式 A：定位左侧/右侧课程章节目录树中的所有可点击小节节点
            const selectors = [
                '.posCatalog_select',
                '.ncells h4 a',
                '.ncells .cells h4',
                '.chapter_item',
                '#coursetree li div[onclick], #coursetree .posCatalog_name'
            ];

            let units = [];
            for (const sel of selectors) {
                const found = Array.from(document.querySelectorAll(sel)).filter(el => {
                    // 过滤纯章标题（无小节点击事件的父节点）
                    if (el.classList.contains('firstLayer')) return false;
                    return true;
                });
                if (found.length > 1) {
                    units = found;
                    break;
                }
            }

            if (units.length > 0) {
                let activeIdx = units.findIndex(el =>
                    el.classList.contains('posCatalog_active') ||
                    el.classList.contains('currents') ||
                    el.classList.contains('cur') ||
                    el.querySelector('.posCatalog_active, .currents, .orange01')
                );

                if (activeIdx !== -1 && activeIdx + 1 < units.length) {
                    const nextEl = units[activeIdx + 1];
                    const clickTarget = nextEl.querySelector('a, span.posCatalog_name, .clicktitle') || nextEl;
                    const nextTitle = (clickTarget.textContent || '').replace(/\s+/g, ' ').trim();
                    this.log(`正在切换到下一小节: ${nextTitle || ('第 ' + (activeIdx + 2) + ' 节')}`, 'action');
                    this.setStatus('正在切换章节', `进入: ${nextTitle.slice(0, 18)}...`);
                    clickTarget.click();
                    return true;
                } else if (activeIdx === units.length - 1) {
                    this.log('🎉 恭喜！课程目录中的最后一个小节已全部完成！', 'success');
                    this.configs.running = false;
                    saveConfigs(this.configs);
                    this.setStatus('🎉 课程已全部刷完', '所有小节均已遍历完成');
                    return false;
                }
            }

            // 方式 B：回退点击页面上的“下一节”按钮
            const nextBtn = this.findNextButtonInDocs();
            if (nextBtn) {
                this.log('通过页面“下一节”按钮切换章节...', 'action');
                nextBtn.click();
                return true;
            }

            this.log('未找到下一小节入口，请手动在右侧目录点击下一节。', 'warn');
            this.setStatus('等待手动选节', '未能自动定位下一节目录');
            return false;
        },

        // 8. 主循环心跳检查
        tick() {
            if (!this.configs.running) return;

            // 优先查找页面中的视频元素
            const video = this.findVideoElement();
            if (video) {
                this.handleVideo(video);
                return;
            }

            // 若无视频，检查是否有顶部“2视频”标签可切入
            if (this.trySwitchToVideoTab()) {
                this.setStatus('切换视频页签中', '正在从学习目标进入视频页...');
                return;
            }

            // 检查是否为章节测验页
            const quizCtx = this.findQuizContext();
            if (quizCtx) {
                this.handleQuizPage(quizCtx);
                return;
            }

            // 既没有视频也没有测验（如纯 PPT/阅读课件/学习目标页）
            this.state.noVideoWaitCount++;
            const waitedSec = Math.round((this.state.noVideoWaitCount * this.configs.videoCheckInterval) / 1000);
            if (this.configs.autoAdvanceNoVideo) {
                this.setStatus('非视频课件页', `将在 ${Math.max(0, this.configs.noVideoWaitSeconds - waitedSec)} 秒后自动跳到下一节`);
                if (waitedSec >= this.configs.noVideoWaitSeconds) {
                    this.log('当前小节未检测到视频（可能是阅读课件或目标页），自动切换下一小节...', 'action');
                    this.state.noVideoWaitCount = 0;
                    this.nextUnit();
                }
            } else {
                this.setStatus('非视频章节', '未检测到视频，可点“立即跳到下一节”');
            }
        },

        // 9. 构建可视化一键操作悬浮面板
        mountUI() {
            if (document.getElementById('xxt-pro-panel')) return;

            const style = document.createElement('style');
            style.textContent = `
                #xxt-pro-panel {
                    position: fixed;
                    top: 90px;
                    right: 22px;
                    width: 310px;
                    background: rgba(18, 24, 38, 0.96);
                    color: #f3f4f6;
                    border-radius: 14px;
                    box-shadow: 0 12px 32px rgba(0, 0, 0, 0.38), 0 0 0 1px rgba(255, 255, 255, 0.1);
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
                    font-size: 13px;
                    z-index: 2147483647;
                    overflow: hidden;
                    backdrop-filter: blur(10px);
                    transition: width 0.2s ease, opacity 0.2s ease;
                    user-select: none;
                }
                
                @media (max-width: 800px) {
                    #xxt-pro-panel {
                        width: 255px;
                        top: 12px;
                        right: 10px;
                        font-size: 12px;
                    }
                    .xxt-body {
                        padding: 10px;
                        gap: 8px;
                    }
                    #xxt-pro-log-list {
                        height: 64px;
                    }
                }

                #xxt-pro-panel.xxt-minimized {
                    width: 170px;
                }
                #xxt-pro-panel.xxt-minimized .xxt-body {
                    display: none;
                }
                .xxt-header {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    padding: 11px 14px;
                    background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
                    cursor: move;
                    font-weight: 600;
                    font-size: 13.5px;
                    letter-spacing: 0.3px;
                }
                .xxt-header-title {
                    display: flex;
                    align-items: center;
                    gap: 6px;
                    color: #fff;
                }
                .xxt-min-btn {
                    background: rgba(255, 255, 255, 0.18);
                    border: none;
                    color: #fff;
                    width: 24px;
                    height: 24px;
                    border-radius: 6px;
                    cursor: pointer;
                    font-size: 12px;
                    line-height: 24px;
                    text-align: center;
                }
                .xxt-min-btn:hover {
                    background: rgba(255, 255, 255, 0.3);
                }
                .xxt-body {
                    padding: 14px;
                    display: flex;
                    flex-direction: column;
                    gap: 11px;
                }
                .xxt-status-card {
                    background: rgba(255, 255, 255, 0.06);
                    border-radius: 10px;
                    padding: 10px 12px;
                    display: flex;
                    flex-direction: column;
                    gap: 5px;
                }
                .xxt-status-row {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }
                .xxt-badge {
                    padding: 3px 8px;
                    border-radius: 999px;
                    font-size: 11.5px;
                    font-weight: 600;
                }
                .xxt-badge-active {
                    background: rgba(16, 185, 129, 0.2);
                    color: #34d399;
                    border: 1px solid rgba(52, 211, 153, 0.35);
                }
                .xxt-badge-paused {
                    background: rgba(245, 158, 11, 0.2);
                    color: #fbbf24;
                    border: 1px solid rgba(251, 191, 36, 0.35);
                }
                .xxt-progress-text {
                    font-size: 12px;
                    color: #9ca3af;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }
                .xxt-btn-group {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 8px;
                }
                .xxt-btn {
                    border: none;
                    border-radius: 8px;
                    padding: 9px 10px;
                    font-size: 12.5px;
                    font-weight: 600;
                    cursor: pointer;
                    transition: transform 0.1s, opacity 0.15s;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    gap: 4px;
                }
                .xxt-btn:active {
                    transform: scale(0.97);
                }
                .xxt-btn-running {
                    background: #ef4444;
                    color: #fff;
                }
                .xxt-btn-stopped {
                    background: #10b981;
                    color: #fff;
                }
                .xxt-btn-secondary {
                    background: rgba(255, 255, 255, 0.1);
                    color: #e5e7eb;
                }
                .xxt-btn-secondary:hover {
                    background: rgba(255, 255, 255, 0.16);
                }
                .xxt-setting-row {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    font-size: 12.5px;
                    color: #d1d5db;
                }
                .xxt-select, .xxt-input {
                    background: rgba(31, 41, 55, 0.95);
                    color: #f9fafb;
                    border: 1px solid rgba(255, 255, 255, 0.15);
                    border-radius: 6px;
                    padding: 4px 8px;
                    font-size: 12px;
                    outline: none;
                }
                .xxt-input {
                    width: 100%;
                    box-sizing: border-box;
                    margin-top: 4px;
                }
                .xxt-switch {
                    position: relative;
                    display: inline-block;
                    width: 36px;
                    height: 20px;
                }
                .xxt-switch input {
                    opacity: 0;
                    width: 0;
                    height: 0;
                }
                .xxt-slider {
                    position: absolute;
                    cursor: pointer;
                    top: 0; left: 0; right: 0; bottom: 0;
                    background-color: #4b5563;
                    transition: .2s;
                    border-radius: 20px;
                }
                .xxt-slider:before {
                    position: absolute;
                    content: "";
                    height: 14px;
                    width: 14px;
                    left: 3px;
                    bottom: 3px;
                    background-color: white;
                    transition: .2s;
                    border-radius: 50%;
                }
                input:checked + .xxt-slider {
                    background-color: #3b82f6;
                }
                input:checked + .xxt-slider:before {
                    transform: translateX(16px);
                }
                .xxt-ai-drawer {
                    background: rgba(37, 99, 235, 0.12);
                    border: 1px solid rgba(59, 130, 246, 0.3);
                    border-radius: 8px;
                    padding: 8px 10px;
                    font-size: 11.5px;
                    display: none;
                }
                .xxt-ai-drawer.show {
                    display: block;
                }
                #xxt-pro-log-list {
                    background: rgba(0, 0, 0, 0.35);
                    border-radius: 8px;
                    padding: 7px 9px;
                    height: 82px;
                    overflow-y: auto;
                    font-size: 11.5px;
                    line-height: 1.45;
                    color: #9ca3af;
                    border: 1px solid rgba(255, 255, 255, 0.06);
                }
                .xxt-log-item {
                    margin-bottom: 3px;
                    word-break: break-all;
                }
                .xxt-log-success { color: #34d399; }
                .xxt-log-warn { color: #fbbf24; }
                .xxt-log-error { color: #f87171; }
                .xxt-log-action { color: #60a5fa; }
            `;
            document.head.appendChild(style);

            const panel = document.createElement('div');
            panel.id = 'xxt-pro-panel';
            if (this.configs.minimized) panel.classList.add('xxt-minimized');

            panel.innerHTML = `
                <div class="xxt-header" id="xxt-pro-drag-handle">
                    <div class="xxt-header-title">
                        <span>⚡ 学习通一键助手</span>
                        <small style="font-size:10.5px;opacity:0.85;">V3 Pro</small>
                    </div>
                    <button class="xxt-min-btn" id="xxt-pro-min-btn" title="折叠/展开面板">${this.configs.minimized ? '展开' : '—'}</button>
                </div>
                <div class="xxt-body">
                    <div class="xxt-status-card">
                        <div class="xxt-status-row">
                            <span style="font-weight:600;color:#e5e7eb;">当前状态</span>
                            <span id="xxt-pro-status-badge" class="xxt-badge xxt-badge-active">初始化中</span>
                        </div>
                        <div id="xxt-pro-progress-text" class="xxt-progress-text">正在扫描当前页面结构...</div>
                    </div>

                    <div class="xxt-btn-group">
                        <button id="xxt-pro-toggle-btn" class="xxt-btn xxt-btn-running">⏸ 暂停自动刷课</button>
                        <button id="xxt-pro-next-btn" class="xxt-btn xxt-btn-secondary">⏭ 跳到下一节</button>
                    </div>

                    <div class="xxt-setting-row">
                        <span>🚀 视频播放倍速</span>
                        <select id="xxt-pro-rate-select" class="xxt-select">
                            <option value="1">1.0x (默认最稳)</option>
                            <option value="1.25">1.25x</option>
                            <option value="1.5">1.5x (原版默认)</option>
                            <option value="2">2.0x (极速)</option>
                        </select>
                    </div>

                    <div class="xxt-setting-row">
                        <span>🔇 自动静音播放</span>
                        <label class="xxt-switch">
                            <input type="checkbox" id="xxt-pro-mute-chk">
                            <span class="xxt-slider"></span>
                        </label>
                    </div>

                    <div class="xxt-setting-row">
                        <span title="遇到纯PPT/文档/无视频小节时等待6秒自动进入下一节">📄 无视频小节自动跳过</span>
                        <label class="xxt-switch">
                            <input type="checkbox" id="xxt-pro-novideo-chk">
                            <span class="xxt-slider"></span>
                        </label>
                    </div>

                    <div class="xxt-setting-row">
                        <span>📝 遇到章节测验时</span>
                        <select id="xxt-pro-quiz-select" class="xxt-select">
                            <option value="skip">自动跳过测验</option>
                            <option value="pause">暂停并提醒我</option>
                            <option value="ai">DeepSeek AI 辅助答题</option>
                        </select>
                    </div>

                    <div id="xxt-pro-ai-drawer" class="xxt-ai-drawer">
                        <div style="color:#93c5fd;font-weight:600;margin-bottom:2px;">🤖 DeepSeek API Key (免本地服务直连)</div>
                        <input type="password" id="xxt-pro-apikey-input" class="xxt-input" placeholder="粘贴 sk-... 密钥，自动保存在本地">
                        <div style="display:flex;justify-content:space-between;align-items:center;margin-top:6px;">
                            <span style="color:#d1d5db;">AI 勾选后自动跳下一节</span>
                            <input type="checkbox" id="xxt-pro-autosubmit-chk">
                        </div>
                    </div>

                    <div id="xxt-pro-log-list"></div>
                </div>
            `;

            document.body.appendChild(panel);
            this.bindUIEvents(panel);
            this.syncPanelInputs();
            this.setStatus(this.configs.running ? '正在守护运行' : '已暂停', '等待扫描课程节点...');
        },

        syncPanelInputs() {
            const rateSelect = document.getElementById('xxt-pro-rate-select');
            const muteChk = document.getElementById('xxt-pro-mute-chk');
            const noVideoChk = document.getElementById('xxt-pro-novideo-chk');
            const quizSelect = document.getElementById('xxt-pro-quiz-select');
            const aiDrawer = document.getElementById('xxt-pro-ai-drawer');
            const apiKeyInput = document.getElementById('xxt-pro-apikey-input');
            const autoSubmitChk = document.getElementById('xxt-pro-autosubmit-chk');

            if (rateSelect) rateSelect.value = String(this.configs.playbackRate);
            if (muteChk) muteChk.checked = !!this.configs.muted;
            if (noVideoChk) noVideoChk.checked = !!this.configs.autoAdvanceNoVideo;
            if (quizSelect) quizSelect.value = this.configs.quizMode || 'skip';
            if (aiDrawer) {
                aiDrawer.classList.toggle('show', this.configs.quizMode === 'ai');
            }
            if (apiKeyInput) apiKeyInput.value = this.configs.deepseekApiKey || '';
            if (autoSubmitChk) autoSubmitChk.checked = !!this.configs.autoSubmitQuiz;
        },

        bindUIEvents(panel) {
            // 折叠/展开
            const minBtn = document.getElementById('xxt-pro-min-btn');
            minBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.configs.minimized = !this.configs.minimized;
                saveConfigs(this.configs);
                panel.classList.toggle('xxt-minimized', this.configs.minimized);
                minBtn.textContent = this.configs.minimized ? '展开' : '—';
            });

            // 一键开始/暂停
            document.getElementById('xxt-pro-toggle-btn').addEventListener('click', () => {
                this.configs.running = !this.configs.running;
                saveConfigs(this.configs);
                if (this.configs.running) {
                    this.state.retryCount = 0;
                    this.log('已恢复自动刷课！', 'success');
                    this.setStatus('运行中', '正在重新接管页面...');
                    this.tick();
                } else {
                    const video = this.findVideoElement();
                    if (video && !video.paused) video.pause();
                    this.log('已暂停自动刷课。', 'warn');
                    this.setStatus('已暂停', '点击“一键开始刷课”继续');
                }
            });

            // 立即跳到下一节
            document.getElementById('xxt-pro-next-btn').addEventListener('click', () => {
                this.log('手动触发：立即跳到下一小节', 'action');
                this.nextUnit();
            });

            // 倍速选择
            document.getElementById('xxt-pro-rate-select').addEventListener('change', (e) => {
                this.configs.playbackRate = Number(e.target.value) || 1.0;
                saveConfigs(this.configs);
                const video = this.findVideoElement();
                if (video) video.playbackRate = this.configs.playbackRate;
                this.log(`播放倍速已调整为 ${this.configs.playbackRate}x`, 'info');
            });

            // 静音开关
            document.getElementById('xxt-pro-mute-chk').addEventListener('change', (e) => {
                this.configs.muted = e.target.checked;
                saveConfigs(this.configs);
                const video = this.findVideoElement();
                if (video) video.muted = this.configs.muted;
                this.log(`静音模式已${this.configs.muted ? '开启' : '关闭'}`, 'info');
            });

            // 无视频自动跳过开关
            document.getElementById('xxt-pro-novideo-chk').addEventListener('change', (e) => {
                this.configs.autoAdvanceNoVideo = e.target.checked;
                saveConfigs(this.configs);
                this.log(`无视频小节自动跳过已${this.configs.autoAdvanceNoVideo ? '开启' : '关闭'}`, 'info');
            });

            // 测验策略切换
            document.getElementById('xxt-pro-quiz-select').addEventListener('change', (e) => {
                this.configs.quizMode = e.target.value;
                saveConfigs(this.configs);
                document.getElementById('xxt-pro-ai-drawer').classList.toggle('show', this.configs.quizMode === 'ai');
                this.log(`章节测验策略已切换为: ${e.target.options[e.target.selectedIndex].text}`, 'info');
            });

            // DeepSeek API Key 保存
            document.getElementById('xxt-pro-apikey-input').addEventListener('change', (e) => {
                this.configs.deepseekApiKey = e.target.value.trim();
                saveConfigs(this.configs);
                this.log('DeepSeek API Key 已保存在浏览器本地。', 'success');
            });

            document.getElementById('xxt-pro-autosubmit-chk').addEventListener('change', (e) => {
                this.configs.autoSubmitQuiz = e.target.checked;
                saveConfigs(this.configs);
            });

            // 拖拽面板支持
            const handle = document.getElementById('xxt-pro-drag-handle');
            let isDragging = false, startX = 0, startY = 0, origRight = 22, origTop = 90;
            handle.addEventListener('mousedown', (e) => {
                if (e.target === minBtn) return;
                isDragging = true;
                startX = e.clientX;
                startY = e.clientY;
                const rect = panel.getBoundingClientRect();
                origRight = window.innerWidth - rect.right;
                origTop = rect.top;
                e.preventDefault();
            });
            document.addEventListener('mousemove', (e) => {
                if (!isDragging) return;
                const dx = e.clientX - startX;
                const dy = e.clientY - startY;
                panel.style.right = Math.max(8, origRight - dx) + 'px';
                panel.style.top = Math.max(8, origTop + dy) + 'px';
            });
            document.addEventListener('mouseup', () => {
                isDragging = false;
            });

            // 手机触屏拖拽支持 (Touch Events)
            handle.addEventListener('touchstart', (e) => {
                if (e.target === minBtn) return;
                const touch = e.touches[0];
                isDragging = true;
                startX = touch.clientX;
                startY = touch.clientY;
                const rect = panel.getBoundingClientRect();
                origRight = window.innerWidth - rect.right;
                origTop = rect.top;
            }, { passive: true });
            document.addEventListener('touchmove', (e) => {
                if (!isDragging) return;
                const touch = e.touches[0];
                const dx = touch.clientX - startX;
                const dy = touch.clientY - startY;
                panel.style.right = Math.max(6, origRight - dx) + 'px';
                panel.style.top = Math.max(6, origTop + dy) + 'px';
            }, { passive: true });
            document.addEventListener('touchend', () => {
                isDragging = false;
            });

        },

        // 启动入口
        run() {
            this.mountUI();
            this.log('学习通一键刷课助手 V3 Pro 已就绪！', 'success');
            if (this.state.checkTimer) clearInterval(this.state.checkTimer);
            this.state.checkTimer = setInterval(() => this.tick(), this.configs.videoCheckInterval);
            setTimeout(() => this.tick(), 800);
        }
    };

    // 暴露全局 app 兼容原版控制台命令 (app.run(), app.nextUnit())
    window.app = app;

    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        app.run();
    } else {
        window.addEventListener('DOMContentLoaded', () => app.run());
    }
})();
